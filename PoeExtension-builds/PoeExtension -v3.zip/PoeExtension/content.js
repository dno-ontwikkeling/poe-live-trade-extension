// Content script that monitors alerts and clicks the hideout button
console.log('[POE Extension] Content script file executing...')

// Prevent duplicate execution
if (window.__POE_CONTENT_SCRIPT_LOADED) {
  console.log('[POE Extension] Content script already loaded, skipping...')
} else {
  window.__POE_CONTENT_SCRIPT_LOADED = true

  ;(function () {
    'use strict'

    console.log('[POE Extension] Content script IIFE started')

    let extensionEnabled = true // Enabled by default when injected
    let autoClickEnabled = false // Auto-click DISABLED by default on startup
    let alertLog = []
    let currentTabId = null

    // Get current tab ID and load auto-click state from local storage
    chrome.runtime.sendMessage({ type: 'getTabId' }, response => {
      if (response && response.tabId) {
        currentTabId = response.tabId
        try {
          chrome.storage.local.get([`autoClick_${currentTabId}`], result => {
            if (chrome.runtime.lastError) {
              console.log(
                '[POE Extension] Could not access local storage:',
                chrome.runtime.lastError.message
              )
              return
            }
            if (result) {
              const savedState = result[`autoClick_${currentTabId}`]
              if (savedState !== undefined) {
                autoClickEnabled = savedState
                console.log(
                  '[POE Extension] Loaded auto-click state from storage:',
                  autoClickEnabled
                )
              }
            }
          })
        } catch (error) {
          console.log('[POE Extension] Storage access error:', error)
        }
      }
    })

    // Listen for messages from background/popup
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
      if (request.action === 'ping') {
        // Respond to ping to indicate content script is loaded
        sendResponse({ alive: true })
      } else if (request.action === 'enableExtension') {
        extensionEnabled = true
        console.log('[POE Extension] Extension enabled')

        // Re-enable notification interception in page context
        window.postMessage({ type: 'POE_ENABLE_INTERCEPTION' }, '*')

        sendResponse({ success: true })
      } else if (request.action === 'disableExtension') {
        extensionEnabled = false
        autoClickEnabled = false
        console.log('[POE Extension] Extension disabled')

        // Disable notification interception in page context
        window.postMessage({ type: 'POE_DISABLE_INTERCEPTION' }, '*')

        // Save disabled state to local storage
        if (currentTabId) {
          try {
            const state = {}
            state[`autoClick_${currentTabId}`] = false
            chrome.storage.local.set(state, () => {
              if (chrome.runtime.lastError) {
                console.log(
                  '[POE Extension] Could not save to local storage:',
                  chrome.runtime.lastError.message
                )
              }
            })
          } catch (error) {
            console.log('[POE Extension] Storage access error:', error)
          }
        }

        sendResponse({ success: true })
      } else if (request.action === 'enableAutoClick') {
        autoClickEnabled = true
        console.log('[POE Extension] Auto-click re-enabled')

        // Save state to local storage
        if (currentTabId) {
          try {
            const state = {}
            state[`autoClick_${currentTabId}`] = true
            chrome.storage.local.set(state, () => {
              if (chrome.runtime.lastError) {
                console.log(
                  '[POE Extension] Could not save to local storage:',
                  chrome.runtime.lastError.message
                )
              }
            })
          } catch (error) {
            console.log('[POE Extension] Storage access error:', error)
          }
        }

        sendResponse({ success: true })
      } else if (request.action === 'disableAutoClick') {
        autoClickEnabled = false
        console.log('[POE Extension] Auto-click disabled')

        // Save state to local storage
        if (currentTabId) {
          try {
            const state = {}
            state[`autoClick_${currentTabId}`] = false
            chrome.storage.local.set(state, () => {
              if (chrome.runtime.lastError) {
                console.log(
                  '[POE Extension] Could not save to local storage:',
                  chrome.runtime.lastError.message
                )
              }
            })
          } catch (error) {
            console.log('[POE Extension] Storage access error:', error)
          }
        }

        sendResponse({ success: true })
      } else if (request.action === 'getAlertLog') {
        sendResponse({ alerts: alertLog })
      } else if (request.action === 'clearAlertLog') {
        alertLog = []
        sendResponse({ success: true })
      }
      return true
    })

    // Inject script into page context to intercept Notification
    // Note: This is now handled by popup.js using chrome.scripting.executeScript with world: 'MAIN'
    // No need to manually inject here anymore

    // Listen for messages from page context
    window.addEventListener('message', event => {
      if (event.source !== window) return

      console.log('[POE Extension] Message received:', event.data.type)

      if (event.data.type === 'POE_NOTIFICATION_INTERCEPTED') {
        handleInterceptedNotification(event.data.title, event.data.options)
      }
    })

    function handleInterceptedNotification (title, options) {
      console.log(
        '[POE Extension] Notification intercepted in content script:',
        title,
        options
      )

      const message =
        title + (options && options.body ? ' - ' + options.body : '')
      const alertEntry = {
        timestamp: new Date().toISOString(),
        message: message,
        action: 'intercepted'
      }

      alertLog.push(alertEntry)
      if (alertLog.length > 5) {
        alertLog.shift()
      }

      // Send message with error handling for invalidated context
      try {
        chrome.runtime.sendMessage({
          type: 'alertIntercepted',
          alert: alertEntry
        })
      } catch (error) {
        console.log(
          '[POE Extension] Could not send message (extension may have been reloaded):',
          error
        )
      }

      if (extensionEnabled) {
        // Wait for HTML to load before finding button
        setTimeout(() => {
          if (autoClickEnabled) {
            console.log(
              '[POE Extension] Auto-click is enabled, disabling it and clicking hideout button...'
            )

            // Disable auto-click FIRST
            autoClickEnabled = false

            // Save disabled state to local storage
            if (currentTabId) {
              try {
                const state = {}
                state[`autoClick_${currentTabId}`] = false
                chrome.storage.local.set(state, () => {
                  if (chrome.runtime.lastError) {
                    console.log(
                      '[POE Extension] Could not save to local storage:',
                      chrome.runtime.lastError.message
                    )
                  }
                })
              } catch (error) {
                console.log('[POE Extension] Storage access error:', error)
              }
            }

            // Notify that auto-click was disabled
            try {
              chrome.runtime.sendMessage({ type: 'autoClickDisabled' })
            } catch (error) {
              console.log('[POE Extension] Could not send message:', error)
            }

            const buttonClicked = findAndClickHideoutButton()

            if (buttonClicked) {
              alertEntry.action = 'button_clicked'

              // Notify popup to show confirmation buttons
              try {
                chrome.runtime.sendMessage({
                  type: 'showConfirmation',
                  tabId: currentTabId
                })
              } catch (error) {
                console.log('[POE Extension] Could not send message:', error)
              }
            } else {
              alertEntry.action = 'button_not_found'
            }
          } else {
            console.log(
              '[POE Extension] Auto-click is disabled, not clicking button...'
            )
            alertEntry.action = 'auto_click_disabled'
          }

          try {
            chrome.runtime.sendMessage({
              type: 'alertUpdated',
              alert: alertEntry
            })
          } catch (error) {
            console.log('[POE Extension] Could not send message:', error)
          }
        }, 1500)
      } else {
        console.log(
          '[POE Extension] Extension is disabled, ignoring notification'
        )
      }
    }

    // Function to find and click the "Travel to hideout" button
    function findAndClickHideoutButton () {
      // Look for buttons with text "Travel to hideout" or similar
      const buttons = document.querySelectorAll(
        'button, a, input[type="button"], input[type="submit"]'
      )

      for (const button of buttons) {
        const text = button.textContent || button.value || ''
        if (
          text.toLowerCase().includes('travel to hideout') ||
          text.toLowerCase().includes('hideout')
        ) {
          console.log('[POE Extension] Found hideout button:', button)

          // Check if button is enabled
          if (!button.disabled && button.offsetParent !== null) {
            // Click the button once
            button.click()
            console.log('[POE Extension] Clicked hideout button')
            
            // After 200ms, check for and click the "In demand. Teleport anyway?" button
            setTimeout(() => {
              findAndClickTeleportAnywayButton()
            }, 200)
            
            return true
          } else {
            console.log('[POE Extension] Button found but disabled or hidden')
          }
        }
      }

      console.log('[POE Extension] No hideout button found')
      return false
    }

    // Function to find and click the "In demand. Teleport anyway?" button
    function findAndClickTeleportAnywayButton () {
      const buttons = document.querySelectorAll(
        'button, a, input[type="button"], input[type="submit"]'
      )

      for (const button of buttons) {
        const text = button.textContent || button.value || ''
        if (
          text.toLowerCase().includes('in demand') ||
          text.toLowerCase().includes('teleport anyway')
        ) {
          console.log('[POE Extension] Found "Teleport anyway" button:', button)

          // Check if button is enabled
          if (!button.disabled && button.offsetParent !== null) {
            // Click the button
            button.click()
            console.log('[POE Extension] Clicked "Teleport anyway" button')
            return true
          } else {
            console.log('[POE Extension] "Teleport anyway" button found but disabled or hidden')
          }
        }
      }

      console.log('[POE Extension] No "Teleport anyway" button found (this is normal if not in demand)')
      return false
    }

    // Initialize
    console.log(
      '[POE Extension] Content script initialized - Extension enabled:',
      extensionEnabled,
      'Auto-click:',
      autoClickEnabled
    )
  })()
}
