// Content script that monitors alerts and clicks the hideout button
console.log('[POE Extension] Content script file executing...')

// Prevent duplicate execution
if (window.__POE_CONTENT_SCRIPT_LOADED) {
  console.log('[POE Extension] Content script already loaded, skipping...')
} else {
  window.__POE_CONTENT_SCRIPT_LOADED = true
  ;(function () {
    'use strict'

    console.log('[POE Extension] Content script IIFE started')

    let extensionEnabled = true // Enabled by default when injected
    let autoClickEnabled = false // Auto-click DISABLED by default on startup
    let alertLog = []
    let currentTabId = null
    let confirmationOverlay = null
    let lastPlayerName = null // Track the player name from notification

    // Create confirmation overlay UI
    function createConfirmationOverlay () {
      const overlay = document.createElement('div')
      overlay.id = 'poe-extension-confirmation-overlay'
      overlay.innerHTML = `
        <div class="poe-ext-modal">
          <div class="poe-ext-header">
            <img src="${chrome.runtime.getURL(
              'PoeLogo.png'
            )}" alt="POE Trade" class="poe-ext-logo">
            <h3>Auto-Clicker</h3>
          </div>
          <div class="poe-ext-content">
            <p>Hideout button was auto-clicked!</p>
            <p class="poe-ext-subtitle">Continue monitoring or keep it disabled?</p>
          </div>
          <div class="poe-ext-buttons">
            <button id="poe-ext-continue" class="poe-ext-btn poe-ext-btn-primary">
              ✓ Continue Monitoring
            </button>
            <button id="poe-ext-disable" class="poe-ext-btn poe-ext-btn-secondary">
              ✗ Keep Disabled
            </button>
          </div>
        </div>
      `

      // Add styles
      const style = document.createElement('style')
      style.textContent = `
        #poe-extension-confirmation-overlay {
          position: fixed;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          background: rgba(0, 0, 0, 0.7);
          display: flex;
          justify-content: center;
          align-items: center;
          z-index: 999999;
          animation: poe-ext-fadeIn 0.3s ease;
        }
        .poe-ext-modal {
          background: #1e1e1e;
          border: 2px solid #af6025;
          border-radius: 8px;
          padding: 24px;
          max-width: 400px;
          box-shadow: 0 8px 32px rgba(0, 0, 0, 0.5);
          animation: poe-ext-slideIn 0.3s ease;
        }
        .poe-ext-header {
          margin-bottom: 16px;
          border-bottom: 2px solid #af6025;
          padding-bottom: 12px;
          display: flex;
          align-items: center;
          gap: 12px;
        }
        .poe-ext-logo {
          width: 120px;
          height: auto;
        }
        .poe-ext-header h3 {
          margin: 0;
          color: #af6025;
          font-size: 20px;
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        }
        .poe-ext-content {
          margin-bottom: 20px;
        }
        .poe-ext-content p {
          margin: 8px 0;
          color: #fff;
          font-size: 16px;
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        }
        .poe-ext-subtitle {
          font-size: 14px !important;
          color: #999 !important;
        }
        .poe-ext-buttons {
          display: flex;
          gap: 12px;
        }
        .poe-ext-btn {
          flex: 1;
          padding: 12px 20px;
          border: none;
          border-radius: 4px;
          font-size: 14px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s;
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        }
        .poe-ext-btn-primary {
          background: #af6025;
          color: #fff;
        }
        .poe-ext-btn-primary:hover {
          background: #c97033;
          transform: translateY(-1px);
          box-shadow: 0 4px 12px rgba(175, 96, 37, 0.4);
        }
        .poe-ext-btn-secondary {
          background: #333;
          color: #fff;
        }
        .poe-ext-btn-secondary:hover {
          background: #444;
          transform: translateY(-1px);
        }
        @keyframes poe-ext-fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        @keyframes poe-ext-slideIn {
          from { transform: translateY(-20px); opacity: 0; }
          to { transform: translateY(0); opacity: 1; }
        }
      `

      document.head.appendChild(style)
      document.body.appendChild(overlay)

      // Add event listeners
      document
        .getElementById('poe-ext-continue')
        .addEventListener('click', () => {
          handleContinueMonitoring()
        })

      document
        .getElementById('poe-ext-disable')
        .addEventListener('click', () => {
          handleDisableAutoClick()
        })

      return overlay
    }

    // Show confirmation overlay
    function showConfirmationOverlay () {
      if (!confirmationOverlay) {
        confirmationOverlay = createConfirmationOverlay()
      } else {
        confirmationOverlay.style.display = 'flex'
      }
    }

    // Hide confirmation overlay
    function hideConfirmationOverlay () {
      if (confirmationOverlay) {
        confirmationOverlay.style.display = 'none'
      }
    }

    // Handle continue monitoring
    function handleContinueMonitoring () {
      autoClickEnabled = true
      saveAutoClickState(true)

      hideConfirmationOverlay()
      console.log('[POE Extension] Auto-click re-enabled from overlay')

      // Notify background
      try {
        chrome.runtime.sendMessage({ type: 'autoClickEnabled' })
      } catch (error) {
        console.log('[POE Extension] Could not send message:', error)
      }
    }

    // Handle disable auto-click
    function handleDisableAutoClick () {
      autoClickEnabled = false

      console.log('[POE Extension] Disabling auto-click globally')
      saveAutoClickState(false)

      hideConfirmationOverlay()
      console.log('[POE Extension] Auto-click kept disabled from overlay')

      // Notify background and popup
      try {
        chrome.runtime.sendMessage({ type: 'autoClickDisabled' })
      } catch (error) {
        console.log('[POE Extension] Could not send message:', error)
      }
    }

    // Helper function to save auto-click state to global storage via background
    function saveAutoClickState (enabled) {
      const state = { autoClickEnabled: enabled }
      console.log('[POE Extension] Saving global auto-click state:', enabled)

      chrome.runtime.sendMessage(
        { type: 'saveAutoClickState', enabled: enabled },
        response => {
          if (response && response.success) {
            console.log(
              '[POE Extension] Successfully saved auto-click state:',
              enabled
            )
          } else {
            console.log(
              '[POE Extension] Failed to save auto-click state:',
              response?.error
            )
          }
        }
      )
    }

    // Get current tab ID and load auto-click state from global storage
    chrome.runtime.sendMessage({ type: 'getTabId' }, response => {
      if (response && response.tabId) {
        currentTabId = response.tabId

        // Load global auto-click state from background
        chrome.runtime.sendMessage({ type: 'getAutoClickState' }, response => {
          if (response && response.success) {
            autoClickEnabled = response.enabled === true
            console.log(
              '[POE Extension] Loaded global auto-click state:',
              autoClickEnabled
            )

            // Show confirmation overlay if needed
            if (autoClickEnabled) {
              console.log('[POE Extension] Auto-click is enabled globally')
            }
          } else {
            console.log(
              '[POE Extension] Could not load auto-click state:',
              response?.error
            )
          }
        })
      }
    })

    // Listen for messages from background/popup
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
      if (request.action === 'ping') {
        // Respond to ping to indicate content script is loaded
        sendResponse({ alive: true })
      } else if (request.action === 'enableExtension') {
        extensionEnabled = true
        console.log('[POE Extension] Extension enabled')

        // Re-enable notification interception in page context
        window.postMessage({ type: 'POE_ENABLE_INTERCEPTION' }, '*')

        sendResponse({ success: true })
      } else if (request.action === 'disableExtension') {
        extensionEnabled = false
        autoClickEnabled = false
        console.log('[POE Extension] Extension disabled')

        // Disable notification interception in page context
        window.postMessage({ type: 'POE_DISABLE_INTERCEPTION' }, '*')

        // Save disabled state to session storage
        saveAutoClickState(false)

        sendResponse({ success: true })
      } else if (request.action === 'enableAutoClick') {
        autoClickEnabled = true
        console.log('[POE Extension] Auto-click re-enabled')
        sendResponse({ success: true })
      } else if (request.action === 'disableAutoClick') {
        autoClickEnabled = false
        console.log('[POE Extension] Auto-click disabled')
        sendResponse({ success: true })
      } else if (request.action === 'getAlertLog') {
        sendResponse({ alerts: alertLog })
      } else if (request.action === 'clearAlertLog') {
        alertLog = []
        sendResponse({ success: true })
      }
      return true
    })

    // Listen for messages from page context
    window.addEventListener('message', event => {
      if (event.source !== window) return

      console.log('[POE Extension] Message received:', event.data.type)

      if (event.data.type === 'POE_NOTIFICATION_INTERCEPTED') {
        handleInterceptedNotification(event.data.title, event.data.options)
      }
    })

    function handleInterceptedNotification (title, options) {
      console.log(
        '[POE Extension] Notification intercepted in content script:',
        title,
        options
      )

      // Extract player name from notification (format: "PlayerName#1234 listed a few...")
      const playerNameMatch = title.match(/^([^#]+#\d+)/)
      if (playerNameMatch) {
        lastPlayerName = playerNameMatch[1]
        console.log('[POE Extension] Extracted player name:', lastPlayerName)
      } else {
        lastPlayerName = null
        console.log(
          '[POE Extension] Could not extract player name from:',
          title
        )
      }

      const message =
        title + (options && options.body ? ' - ' + options.body : '')
      const alertEntry = {
        timestamp: new Date().toISOString(),
        message: message,
        action: 'intercepted'
      }

      alertLog.push(alertEntry)
      if (alertLog.length > 5) {
        alertLog.shift()
      }

      // Send message with error handling for invalidated context
      try {
        chrome.runtime.sendMessage({
          type: 'alertIntercepted',
          alert: alertEntry
        })
      } catch (error) {
        console.log(
          '[POE Extension] Could not send message (extension may have been reloaded):',
          error
        )
      }

      if (extensionEnabled) {
        // Wait for HTML to load before finding button
        setTimeout(() => {
          if (autoClickEnabled) {
            console.log(
              '[POE Extension] Auto-click is enabled, disabling it and clicking hideout button...'
            )

            // Disable auto-click FIRST
            autoClickEnabled = false

            // Save disabled state to session storage
            saveAutoClickState(false)

            // Notify that auto-click was disabled
            try {
              chrome.runtime.sendMessage({ type: 'autoClickDisabled' })
            } catch (error) {
              console.log('[POE Extension] Could not send message:', error)
            }

            const buttonClicked = findAndClickHideoutButton(lastPlayerName)

            if (buttonClicked) {
              alertEntry.action = 'button_clicked'

              // Show in-page confirmation overlay
              console.log(
                '[POE Extension] Showing confirmation overlay on page'
              )
              showConfirmationOverlay()

              // Also notify popup if it's open
              try {
                chrome.runtime.sendMessage({
                  type: 'showConfirmation',
                  tabId: currentTabId
                })
              } catch (error) {
                console.log('[POE Extension] Could not send message:', error)
              }
            } else {
              alertEntry.action = 'button_not_found'
            }
          } else {
            console.log(
              '[POE Extension] Auto-click is disabled, not clicking button...'
            )
            alertEntry.action = 'auto_click_disabled'
          }

          try {
            chrome.runtime.sendMessage({
              type: 'alertUpdated',
              alert: alertEntry
            })
          } catch (error) {
            console.log('[POE Extension] Could not send message:', error)
          }
        }, 1500)
      } else {
        console.log(
          '[POE Extension] Extension is disabled, ignoring notification'
        )
      }
    }

    // Function to find and click the "Travel to hideout" button based on player name
    function findAndClickHideoutButton (playerName) {
      console.log(
        '[POE Extension] Searching for hideout button for player:',
        playerName
      )

      // Strategy: Find the player name text first, then find the button near it
      if (playerName) {
        // Find all elements containing the player name
        const allElements = document.querySelectorAll('*')
        let playerElement = null

        for (const element of allElements) {
          // Check direct text content (not including children)
          const textContent = Array.from(element.childNodes)
            .filter(node => node.nodeType === Node.TEXT_NODE)
            .map(node => node.textContent)
            .join('')

          if (textContent.includes(playerName)) {
            playerElement = element
            console.log('[POE Extension] Found player element:', element)
            break
          }
        }

        if (playerElement) {
          // Search for "Travel to Hideout" button near this player element
          // Check the parent and nearby siblings
          let searchRoot = playerElement
          for (let i = 0; i < 5; i++) {
            if (searchRoot.parentElement) {
              searchRoot = searchRoot.parentElement
            } else {
              break
            }
          }

          const buttons = searchRoot.querySelectorAll(
            'button, a, input[type="button"], input[type="submit"]'
          )

          for (const button of buttons) {
            const text = button.textContent || button.value || ''
            if (
              text.toLowerCase().includes('travel to hideout') ||
              text.toLowerCase().includes('travel to')
            ) {
              console.log(
                '[POE Extension] Found hideout button for player:',
                button
              )

              // Check if button is enabled
              if (!button.disabled && button.offsetParent !== null) {
                // Click the button twice (POE requires double click)
                button.click()
                console.log('[POE Extension] First click on hideout button')

                // Click again after a short delay
                setTimeout(() => {
                  button.click()
                  console.log('[POE Extension] Second click on hideout button')
                }, 50)

                return true
              } else {
                console.log(
                  '[POE Extension] Button found but disabled or hidden'
                )
              }
            }
          }

          console.log(
            '[POE Extension] Player found but no hideout button nearby'
          )
        } else {
          console.log('[POE Extension] Could not find player element on page')
        }
      }

      // Fallback: search for any "Travel to Hideout" button
      console.log('[POE Extension] Falling back to generic button search')
      const buttons = document.querySelectorAll(
        'button, a, input[type="button"], input[type="submit"]'
      )

      for (const button of buttons) {
        const text = button.textContent || button.value || ''
        if (
          text.toLowerCase().includes('travel to hideout') ||
          text.toLowerCase().includes('travel to')
        ) {
          console.log(
            '[POE Extension] Found hideout button (fallback):',
            button
          )

          // Check if button is enabled
          if (!button.disabled && button.offsetParent !== null) {
            // Click the button twice
            button.click()
            console.log(
              '[POE Extension] First click on hideout button (fallback)'
            )

            setTimeout(() => {
              button.click()
              console.log(
                '[POE Extension] Second click on hideout button (fallback)'
              )
            }, 50)

            return true
          } else {
            console.log('[POE Extension] Button found but disabled or hidden')
          }
        }
      }

      console.log('[POE Extension] No hideout button found')
      return false
    }

    // Initialize
    console.log(
      '[POE Extension] Content script initialized - Extension enabled:',
      extensionEnabled,
      'Auto-click:',
      autoClickEnabled
    )
  })()
}
