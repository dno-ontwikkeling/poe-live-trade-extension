// Popup script
document.addEventListener('DOMContentLoaded', () => {
  const enableExtensionCheckbox = document.getElementById('enableExtension');
  const statusText = document.getElementById('statusText');
  const statusIndicator = document.querySelector('.status-indicator');
  const monitoringStatus = document.getElementById('monitoringStatus');
  const autoClickToggle = document.getElementById('autoClickToggle');
  const clearLogBtn = document.getElementById('clearLog');
  const alertLogDiv = document.getElementById('alertLog');
  const confirmationSection = document.getElementById('confirmationSection');
  const continueBtn = document.getElementById('continueBtn');
  const disableBtn = document.getElementById('disableBtn');

  let currentTabId = null;

  // Load settings and check current tab
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0]) {
      currentTabId = tabs[0].id;
      console.log('[Popup] Current tab ID:', currentTabId);
      
      // Load settings after we have the tab ID
      loadSettings();
      loadAlertLog();
      checkCurrentTab();
    }
  });

  // Continue monitoring button
  continueBtn.addEventListener('click', () => {
    if (!currentTabId) return;
    
    // Enable auto-click
    const state = {};
    state[`autoClick_${currentTabId}`] = true;
    chrome.storage.session.set(state);
    
    // Notify content script to enable auto-click and clear highlights
    chrome.tabs.sendMessage(currentTabId, { action: 'enableAutoClick' });
    
    // Hide confirmation and update toggle
    confirmationSection.style.display = 'none';
    autoClickToggle.checked = true;
    showNotification('Auto-click re-enabled!', 'success');
  });

  // Disable auto-click button
  disableBtn.addEventListener('click', () => {
    if (!currentTabId) return;
    
    // Keep auto-click disabled
    const state = {};
    state[`autoClick_${currentTabId}`] = false;
    chrome.storage.session.set(state);
    
    // Notify content script to disable auto-click and clear highlights
    chrome.tabs.sendMessage(currentTabId, { action: 'disableAutoClick' });
    
    // Hide confirmation and update toggle
    confirmationSection.style.display = 'none';
    autoClickToggle.checked = false;
    showNotification('Auto-click disabled', 'warning');
  });

  // Settings toggle - now injects scripts per tab
  enableExtensionCheckbox.addEventListener('change', async (e) => {
    const enabled = e.target.checked;
    
    chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
      if (!tabs[0]) {
        showNotification('No active tab found', 'warning');
        enableExtensionCheckbox.checked = !enabled;
        return;
      }

      const tab = tabs[0];
      currentTabId = tab.id;
      
      if (enabled) {
        try {
          // First inject the page context script that intercepts notifications
          await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            files: ['inject.js'],
            world: 'MAIN'
          });
          
          // Then inject the content script
          await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            files: ['content.js']
          });
          
          // Store tab-specific state
          const tabState = {};
          tabState[`tab_${tab.id}`] = true;
          chrome.storage.session.set(tabState);
          
          monitoringStatus.textContent = '✅ Monitoring active on this page!';
          monitoringStatus.style.color = '#4caf50';
          updateStatus(true);
          showNotification('Monitoring started!', 'success');
          
          // Do NOT enable auto-click by default - user must enable manually
          
        } catch (error) {
          console.error('Failed to inject script:', error);
          showNotification('Failed to start: ' + error.message, 'warning');
          monitoringStatus.textContent = '❌ Failed to start monitoring';
          monitoringStatus.style.color = '#f44336';
          enableExtensionCheckbox.checked = false;
        }
      } else {
        // Disable monitoring for this tab
        const tabState = {};
        tabState[`tab_${tab.id}`] = false;
        chrome.storage.session.set(tabState);
        
        chrome.tabs.sendMessage(tab.id, { action: 'disableAutoClick' }, () => {
          if (chrome.runtime.lastError) {
            console.log('Tab not monitored or already closed');
          }
        });
        
        monitoringStatus.textContent = 'Monitoring disabled for this page';
        monitoringStatus.style.color = '#999';
        updateStatus(false);
        showNotification('Monitoring stopped', 'warning');
      }
    });
  });

  // Auto-click toggle
  autoClickToggle.addEventListener('change', (e) => {
    const enabled = e.target.checked;
    const action = enabled ? 'enableAutoClick' : 'disableAutoClick';
    
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) {
        currentTabId = tabs[0].id;
        
        // Save to session storage
        const state = {};
        state[`autoClick_${currentTabId}`] = enabled;
        chrome.storage.session.set(state);
        
        // Notify content script
        chrome.tabs.sendMessage(tabs[0].id, { action: action }, (response) => {
          if (chrome.runtime.lastError) {
            // Content script not loaded on this tab
            console.log('Content script not available:', chrome.runtime.lastError.message);
            showNotification('This page doesn\'t support the extension', 'warning');
            autoClickToggle.checked = !enabled;
            return;
          }
          
          if (response && response.success) {
            showNotification(
              enabled ? 'Auto-click enabled' : 'Auto-click disabled',
              enabled ? 'success' : 'warning'
            );
          } else {
            // Reset toggle if message failed
            autoClickToggle.checked = !enabled;
          }
        });
      } else {
        showNotification('No active tab found', 'warning');
        autoClickToggle.checked = !enabled;
      }
    });
  });

  // Clear log button
  clearLogBtn.addEventListener('click', () => {
    chrome.runtime.sendMessage({ type: 'clearAlertHistory' }, (response) => {
      if (response && response.success) {
        alertLogDiv.innerHTML = '<p class="empty-state">No alerts intercepted yet</p>';
        showNotification('Log cleared', 'success');
      }
    });

    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) {
        chrome.tabs.sendMessage(tabs[0].id, { action: 'clearAlertLog' }, () => {
          // Ignore errors if content script not available
          if (chrome.runtime.lastError) {
            console.log('Content script not available on this tab');
          }
        });
      }
    });
  });

  // Check if current tab is being monitored
  function checkCurrentTab() {
    if (!currentTabId) {
      console.log('[Popup] No current tab ID set');
      return;
    }
    
    chrome.storage.session.get([`tab_${currentTabId}`, `autoClick_${currentTabId}`], (result) => {
      const isMonitored = result[`tab_${currentTabId}`] || false;
      const autoClickEnabled = result[`autoClick_${currentTabId}`];
      
      console.log('[Popup] Tab state - Monitored:', isMonitored, 'Auto-click:', autoClickEnabled);
      
      enableExtensionCheckbox.checked = isMonitored;
      
      // Set auto-click toggle state (default to FALSE if not set - disabled on startup)
      autoClickToggle.checked = autoClickEnabled !== undefined ? autoClickEnabled : false;
      
      if (isMonitored) {
        monitoringStatus.textContent = '✅ Monitoring active on this page!';
        monitoringStatus.style.color = '#4caf50';
        updateStatus(true);
      } else {
        monitoringStatus.textContent = 'Toggle extension above to start monitoring this page';
        monitoringStatus.style.color = '#999';
        updateStatus(false);
      }
    });
  }

  // Load settings from storage
  function loadSettings() {
    // Settings are now per-tab, checked in checkCurrentTab()
  }

  // Update status display
  function updateStatus(enabled) {
    if (enabled) {
      statusText.textContent = 'Active - Monitoring alerts';
      statusIndicator.classList.add('active');
      statusIndicator.classList.remove('inactive');
    } else {
      statusText.textContent = 'Inactive - Extension disabled';
      statusIndicator.classList.remove('active');
      statusIndicator.classList.add('inactive');
    }
  }

  // Load alert log
  function loadAlertLog() {
    chrome.runtime.sendMessage({ type: 'getAlertHistory' }, (response) => {
      if (response && response.alerts) {
        displayAlerts(response.alerts);
      }
    });
  }

  // Display alerts in the log
  function displayAlerts(alerts) {
    if (alerts.length === 0) {
      alertLogDiv.innerHTML = '<p class="empty-state">No alerts intercepted yet</p>';
      return;
    }

    alertLogDiv.innerHTML = '';
    
    // Show most recent first
    const recentAlerts = [...alerts].reverse().slice(0, 20);
    
    recentAlerts.forEach(alert => {
      const alertItem = document.createElement('div');
      alertItem.className = 'alert-item';
      
      const timestamp = new Date(alert.timestamp).toLocaleTimeString();
      const actionBadge = getActionBadge(alert.action);
      
      alertItem.innerHTML = `
        <div class="alert-header">
          <span class="alert-time">${timestamp}</span>
          ${actionBadge}
        </div>
        <div class="alert-message">${escapeHtml(alert.message)}</div>
      `;
      
      alertLogDiv.appendChild(alertItem);
    });
  }

  // Get action badge HTML
  function getActionBadge(action) {
    const badges = {
      'intercepted': '<span class="badge badge-info">Intercepted</span>',
      'button_clicked': '<span class="badge badge-success">Button Clicked</span>',
      'button_not_found': '<span class="badge badge-warning">Button Not Found</span>'
    };
    return badges[action] || '<span class="badge">Unknown</span>';
  }

  // Escape HTML to prevent XSS
  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  // Show notification
  function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    document.body.appendChild(notification);

    setTimeout(() => {
      notification.classList.add('show');
    }, 10);

    setTimeout(() => {
      notification.classList.remove('show');
      setTimeout(() => {
        document.body.removeChild(notification);
      }, 300);
    }, 2000);
  }

  // Refresh log every 2 seconds
  setInterval(loadAlertLog, 2000);
  
  // Listen for storage changes to sync toggle state
  chrome.storage.session.onChanged.addListener((changes, namespace) => {
    if (currentTabId && changes[`autoClick_${currentTabId}`]) {
      const newValue = changes[`autoClick_${currentTabId}`].newValue;
      if (newValue !== undefined) {
        console.log('[Popup] Auto-click state changed via storage:', newValue);
        autoClickToggle.checked = newValue;
      }
    }
  });
  
  // Listen for messages from content script to sync state immediately
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.type === 'showConfirmation' && sender.tab && sender.tab.id === currentTabId) {
      console.log('[Popup] Showing confirmation section');
      confirmationSection.style.display = 'block';
    } else if (request.type === 'autoClickEnabled' && sender.tab && sender.tab.id === currentTabId) {
      console.log('[Popup] Auto-click enabled message received');
      autoClickToggle.checked = true;
    } else if (request.type === 'autoClickDisabled' && sender.tab && sender.tab.id === currentTabId) {
      console.log('[Popup] Auto-click disabled message received');
      autoClickToggle.checked = false;
    }
  });
});
