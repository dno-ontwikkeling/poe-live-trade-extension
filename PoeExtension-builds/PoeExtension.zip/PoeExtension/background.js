// Background service worker
let alertHistory = [];

// Listen for messages from content scripts
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'getTabId') {
    // Return the tab ID to content script
    if (sender.tab && sender.tab.id) {
      sendResponse({ tabId: sender.tab.id });
    } else {
      sendResponse({ tabId: null });
    }
  } else if (request.type === 'alertIntercepted') {
    console.log('[Background] Alert intercepted:', request.alert);
    alertHistory.push(request.alert);
    
    // Keep only last 100 alerts
    if (alertHistory.length > 100) {
      alertHistory.shift();
    }
    
    // Update badge to show alert count
    updateBadge();
  } else if (request.type === 'alertUpdated') {
    console.log('[Background] Alert updated:', request.alert);
    // Update the last alert in history
    if (alertHistory.length > 0) {
      alertHistory[alertHistory.length - 1] = request.alert;
    }
  } else if (request.type === 'autoClickEnabled') {
    console.log('[Background] Auto-click enabled');
  } else if (request.type === 'autoClickDisabled') {
    console.log('[Background] Auto-click disabled');
  } else if (request.type === 'getAlertHistory') {
    sendResponse({ alerts: alertHistory });
  } else if (request.type === 'clearAlertHistory') {
    alertHistory = [];
    updateBadge();
    sendResponse({ success: true });
  }
  
  return true;
});

// Update extension badge
function updateBadge() {
  const count = alertHistory.length;
  if (count > 0) {
    chrome.action.setBadgeText({ text: count.toString() });
    chrome.action.setBadgeBackgroundColor({ color: '#ff6b35' });
  } else {
    chrome.action.setBadgeText({ text: '' });
  }
}

// Initialize
console.log('[Background] Service worker initialized');
