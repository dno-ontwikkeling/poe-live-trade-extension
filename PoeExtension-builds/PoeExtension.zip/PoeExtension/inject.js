// This script runs in the page context to intercept Notification API
(function() {
  console.log('[POE Extension - Page Context] Starting injection...');
  const OriginalNotification = window.Notification;
  
  if (OriginalNotification) {
    window.Notification = function(title, options) {
      console.log('[POE Extension - Page Context] Notification intercepted:', title, options);
      
      // Send message to content script
      window.postMessage({
        type: 'POE_NOTIFICATION_INTERCEPTED',
        title: title,
        options: options
      }, '*');
      
      // Create the original notification
      return new OriginalNotification(title, options);
    };
    
    // Copy static properties
    window.Notification.permission = OriginalNotification.permission;
    window.Notification.requestPermission = OriginalNotification.requestPermission.bind(OriginalNotification);
    
    console.log('[POE Extension - Page Context] Notification interceptor installed successfully');
  } else {
    console.log('[POE Extension - Page Context] Notification API not available');
  }
})();
