// Content script that monitors alerts and clicks the hideout button
console.log('[POE Extension] Content script file executing...');
(function() {
  'use strict';
  
  console.log('[POE Extension] Content script IIFE started');

  let extensionEnabled = true; // Enabled by default when injected
  let autoClickEnabled = false; // Auto-click DISABLED by default on startup
  let alertLog = [];
  let currentTabId = null;
  let highlightedButton = null;
  let highlightedRow = null;
  let originalButtonStyle = '';
  let originalRowStyle = '';
  
  // Get current tab ID and load auto-click state from session storage
  chrome.runtime.sendMessage({ type: 'getTabId' }, (response) => {
    if (response && response.tabId) {
      currentTabId = response.tabId;
      chrome.storage.session.get([`autoClick_${currentTabId}`], (result) => {
        const savedState = result[`autoClick_${currentTabId}`];
        if (savedState !== undefined) {
          autoClickEnabled = savedState;
          console.log('[POE Extension] Loaded auto-click state from session:', autoClickEnabled);
        }
      });
    }
  });

  // Function to clear highlights
  function clearHighlights() {
    if (highlightedButton) {
      highlightedButton.style.cssText = originalButtonStyle;
      highlightedButton = null;
    }
    if (highlightedRow) {
      highlightedRow.style.cssText = originalRowStyle;
      highlightedRow = null;
    }
    console.log('[POE Extension] Highlights cleared');
  }

  // Listen for messages from background/popup
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'enableAutoClick') {
      autoClickEnabled = true;
      console.log('[POE Extension] Auto-click re-enabled');
      
      // Save state to session storage
      if (currentTabId) {
        const state = {};
        state[`autoClick_${currentTabId}`] = true;
        chrome.storage.session.set(state);
      }
      
      clearHighlights();
      sendResponse({ success: true });
    } else if (request.action === 'disableAutoClick') {
      autoClickEnabled = false;
      console.log('[POE Extension] Auto-click disabled');
      
      // Save state to session storage
      if (currentTabId) {
        const state = {};
        state[`autoClick_${currentTabId}`] = false;
        chrome.storage.session.set(state);
      }
      
      clearHighlights();
      
      sendResponse({ success: true });
    } else if (request.action === 'getAlertLog') {
      sendResponse({ alerts: alertLog });
    } else if (request.action === 'clearAlertLog') {
      alertLog = [];
      sendResponse({ success: true });
    }
    return true;
  });

  // Inject script into page context to intercept Notification
  // Note: This is now handled by popup.js using chrome.scripting.executeScript with world: 'MAIN'
  // No need to manually inject here anymore

  // Listen for messages from page context
  window.addEventListener('message', (event) => {
    if (event.source !== window) return;
    
    console.log('[POE Extension] Message received:', event.data.type);
    
    if (event.data.type === 'POE_NOTIFICATION_INTERCEPTED') {
      handleInterceptedNotification(event.data.title, event.data.options);
    }
  });

  function handleInterceptedNotification(title, options) {
    console.log('[POE Extension] Notification intercepted in content script:', title, options);
    
    const message = title + (options && options.body ? ' - ' + options.body : '');
    const alertEntry = {
      timestamp: new Date().toISOString(),
      message: message,
      action: 'intercepted'
    };
    
    alertLog.push(alertEntry);
    if (alertLog.length > 50) {
      alertLog.shift();
    }

    // Send message with error handling for invalidated context
    try {
      chrome.runtime.sendMessage({
        type: 'alertIntercepted',
        alert: alertEntry
      });
    } catch (error) {
      console.log('[POE Extension] Could not send message (extension may have been reloaded):', error);
    }

    if (extensionEnabled && autoClickEnabled) {
      console.log('[POE Extension] Auto-click is enabled, disabling it and looking for hideout button...');
      
      // Disable auto-click FIRST
      autoClickEnabled = false;
      
      // Save disabled state to session storage
      if (currentTabId) {
        const state = {};
        state[`autoClick_${currentTabId}`] = false;
        chrome.storage.session.set(state);
      }
      
      // Notify that auto-click was disabled
      try {
        chrome.runtime.sendMessage({ type: 'autoClickDisabled' });
      } catch (error) {
        console.log('[POE Extension] Could not send message:', error);
      }
      
      // Wait for HTML to load before clicking (increased delay)
      setTimeout(() => {
        const buttonClicked = findAndClickHideoutButton();
        
        if (buttonClicked) {
          alertEntry.action = 'button_clicked';
          
          // Notify popup to show confirmation buttons
          try {
            chrome.runtime.sendMessage({ 
              type: 'showConfirmation',
              tabId: currentTabId
            });
          } catch (error) {
            console.log('[POE Extension] Could not send message:', error);
          }
        } else {
          alertEntry.action = 'button_not_found';
        }
        
        try {
          chrome.runtime.sendMessage({
            type: 'alertUpdated',
            alert: alertEntry
          });
        } catch (error) {
          console.log('[POE Extension] Could not send message:', error);
        }
      }, 1500);
    } else {
      console.log('[POE Extension] Auto-click is disabled, not clicking hideout button');
    }
  }

  // Function to find and click the "Travel to hideout" button
  function findAndClickHideoutButton() {
    // Look for buttons with text "Travel to hideout" or similar
    const buttons = document.querySelectorAll('button, a, input[type="button"], input[type="submit"]');
    
    for (const button of buttons) {
      const text = button.textContent || button.value || '';
      if (text.toLowerCase().includes('travel to hideout') || 
          text.toLowerCase().includes('hideout')) {
        console.log('[POE Extension] Found hideout button:', button);
        
        // Check if button is enabled
        if (!button.disabled && button.offsetParent !== null) {
          // Find the parent row/container (try common parent elements)
          let itemRow = button.closest('tr, .row, [class*="row"], [class*="item"], [class*="trade"], [class*="result"]');
          
          // Store highlighted elements and their original styles
          highlightedButton = button;
          originalButtonStyle = button.style.cssText;
          highlightedButton.style.cssText += 'outline: 4px solid #ff0000 !important; outline-offset: 2px !important; box-shadow: 0 0 20px #ff0000 !important;';
          
          // Highlight the parent row if found
          if (itemRow) {
            highlightedRow = itemRow;
            originalRowStyle = itemRow.style.cssText;
            highlightedRow.style.cssText += 'outline: 3px solid #ff6600 !important; outline-offset: 2px !important; background-color: rgba(255, 102, 0, 0.1) !important;';
            console.log('[POE Extension] Highlighted item row:', itemRow);
          }
          
          // Click the button
          button.click();
          console.log('[POE Extension] Clicked hideout button');
          
          // Auto-clear highlights after 10 seconds if not cleared by user action
          setTimeout(() => {
            clearHighlights();
          }, 10000);
          
          return true;
        } else {
          console.log('[POE Extension] Button found but disabled or hidden');
        }
      }
    }
    
    console.log('[POE Extension] No hideout button found');
    return false;
  }

  // Initialize
  console.log('[POE Extension] Content script initialized - Extension enabled:', extensionEnabled, 'Auto-click:', autoClickEnabled);
})();
